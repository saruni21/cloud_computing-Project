import json
import boto3
import re
import time
import html
import uuid

# --- CONFIGURATION ---
AGENT_ID = 'PKVJXD2MSK'
AGENT_ALIAS_ID = 'R4XG73VRD8'
REGION = 'us-east-1'
MAX_RETRIES = 2
CONFIDENCE_THRESHOLD = 0.35

bedrock_runtime = boto3.client("bedrock-agent-runtime", region_name=REGION)


class PromptInjectionFilter:
    def __init__(self):
        self.dangerous_patterns = [
            r'ignore\s+(all\s+)?previous\s+instructions?',
            r'you\s+are\s+now\s+(in\s+)?developer\s+mode',
            r'system\s+override',
            r'reveal\s+prompt',
        ]
        self.fuzzy_patterns = ['ignore', 'bypass', 'override', 'reveal', 'delete', 'system']

    def _is_similar_word(self, word, target):
        if len(word) != len(target) or len(word) < 3:
            return False
        return (word[0] == target[0] and word[-1] == target[-1] and sorted(word[1:-1]) == sorted(target[1:-1]))

    def detect_injection(self, text):
        if any(re.search(p, text, re.IGNORECASE) for p in self.dangerous_patterns):
            return True
        words = re.findall(r'\b\w+\b', text.lower())
        for word in words:
            for pattern in self.fuzzy_patterns:
                if self._is_similar_word(word, pattern):
                    return True
        return False


class OutputValidator:
    def __init__(self):
        self.suspicious_patterns = [
            r'SYSTEM\s*[:]\s*You\s+are',
            r'API[_\s]KEY[:=]\s*\w+',
            r'instructions?[:]\s*\d+\.',
        ]

    def validate_output(self, output):
        return not any(re.search(p, output, re.IGNORECASE) for p in self.suspicious_patterns)


def get_confidence_score(text, query):
    num_samples = 2
    sample_responses = []

    for _ in range(num_samples):
        response = bedrock_runtime.invoke_agent(
            agentId=AGENT_ID,
            agentAliasId=AGENT_ALIAS_ID,
            sessionId=f"confidence-{uuid.uuid4().hex}",
            inputText=query
        )
        completion = ""
        for event in response.get("completion"):
            chunk = event.get("chunk")
            if chunk:
                completion += chunk.get("bytes").decode()
        sample_responses.append(completion)

    def get_ngrams(text, n=3):
        words = re.findall(r'\b\w+\b', text.lower())
        return [tuple(words[i:i+n]) for i in range(len(words) - n + 1)]

    original_ngrams = set(get_ngrams(text))

    agreement_scores = []
    for sample in sample_responses:
        sample_ngrams = set(get_ngrams(sample))
        if len(original_ngrams) > 0 and len(sample_ngrams) > 0:
            intersection = len(original_ngrams.intersection(sample_ngrams))
            union = len(original_ngrams.union(sample_ngrams))
            similarity = intersection / union if union > 0 else 0
        else:
            similarity = 0
        agreement_scores.append(similarity)

    return sum(agreement_scores) / len(agreement_scores) if agreement_scores else 0


def lambda_handler(event, context):
    input_filter = PromptInjectionFilter()
    output_validator = OutputValidator()

    try:
        body = json.loads(event.get('body') or '{}')
        user_input = body.get('prompt', '')
        session_id = f"session-{uuid.uuid4().hex}"

        # Layer 2 — Input validation
        if input_filter.detect_injection(user_input):
            print(f"[SECURITY_ALERT] Injection Attempt Detected: {user_input[:50]}")
            return {"statusCode": 403, "body": json.dumps("I cannot process that request due to security policy.")}

        # Layer 4 — Hallucination defense with retry loop
        attempts = 0
        final_response = ""

        while attempts < MAX_RETRIES:
            response = bedrock_runtime.invoke_agent(
                agentId=AGENT_ID, agentAliasId=AGENT_ALIAS_ID,
                sessionId=session_id, inputText=user_input
            )
            completion = ""
            for event in response.get("completion"):
                chunk = event.get("chunk")
                if chunk:
                    completion += chunk.get("bytes").decode()

            confidence = get_confidence_score(completion, user_input)

            if confidence >= CONFIDENCE_THRESHOLD:
                final_response = completion
                break
            else:
                attempts += 1
                print(f"[SECURITY_WARNING] Hallucination Detected. Score: {confidence}. Attempt: {attempts}")
                user_input = f"I need a more factual answer for: {user_input}"

        if not final_response:
            final_response = "I'm sorry, I'm having trouble verifying the facts for that request."

        # Layer 4 — Output validation
        if not output_validator.validate_output(final_response):
            print(f"[SECURITY_ALERT] Sensitive Data Leakage Blocked in Output")
            return {"statusCode": 200, "body": json.dumps({"answer": "I cannot provide that information for security reasons."})}

        return {
            "statusCode": 200,
            "body": json.dumps({
                "answer": html.escape(final_response),
                "metadata": {"retries": attempts, "security_layer": "OWASP-Hardened-2.0"}
            })
        }

    except Exception as e:
        print(f"[ERROR] Pipeline Failure: {str(e)}")
        return {"statusCode": 500, "body": json.dumps(f"Pipeline Error: {str(e)}")}
